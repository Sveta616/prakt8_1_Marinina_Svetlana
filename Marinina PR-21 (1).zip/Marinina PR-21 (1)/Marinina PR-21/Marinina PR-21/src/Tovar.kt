class Tovar(_edizm:String) {
    var name="Unnamed"
    var price=0.0
    var edizm="Unnamed"
    var vid="Unnamed"
    init{
        edizm=_edizm
    }
    var k=0
    fun Input(tovar:Tovar) {
        try {
            println("Введите название товара")
            tovar.name = readLine()!!.toString()
            do {
                println("Введите цену")
                tovar.price = readLine()!!.toDouble()
            } while (tovar.price <= 0)

            do {
                println("Введите вид товара(Продукт, Мебель, Косметика(со скидкой))")
                tovar.vid = readLine()!!.toString()
            } while (!(tovar.vid == "Продукт") && !(tovar.vid == "Мебель") && !(tovar.vid == "Косметика"))
            do {
                println("Введите кол-во товаров")
                tovar.k = readLine()!!.toInt()
            } while (tovar.k <= 0)
        } catch (e: Exception) {
            println("Данные введены неверно")
        }
    }
            fun Output(tovar:Tovar)
            {
                println("Название товара=${tovar.name}")
                println("Цена товара=${tovar.price}")
                println("Ед измерения=${tovar.edizm}")
                println("Вид товара=${tovar.vid}")
                println("Кол-во товаров=${tovar.k}")
            }
            fun Sckidka(tovar:Tovar)
            {

                if (tovar.vid=="Косметика")
                    tovar.price=tovar.price*0.5
            }



            fun Kol(tovar:Tovar)
            {
                println("Если кол-во товаров больше 15, то следует скидка=>")
                if (tovar.k>15)
                {
                    tovar.price=tovar.price*0.8

                }
            }
    fun Money(tovar:Tovar)
    {
        var money=tovar.price*tovar.k
        if (money<=0)
        {
            println("Нет заработка")
        }
        else
        {
            println("Заработок=${money}")
        }
    }
}





