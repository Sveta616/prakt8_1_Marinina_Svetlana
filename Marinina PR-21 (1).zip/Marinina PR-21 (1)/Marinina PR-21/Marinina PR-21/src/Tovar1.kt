fun main()
{
    try {
  var tovar=Tovar("Рубли")
        tovar.Input(tovar)
        tovar.Sckidka(tovar)
        tovar.Kol(tovar)
        tovar.Money(tovar)
        tovar.Output(tovar)




    }
    catch(e:Exception)
    {
        println("Данные введены неверно")
    }
}